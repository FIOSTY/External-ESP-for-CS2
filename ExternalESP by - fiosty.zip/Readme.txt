instructions:
You don't need to open the dumper, just open the external exe and it applies the offsets automatically from the dumper.

important:
The esp rendering might be delayed sometimes so just uncheck the box or skeleton and it will sync back to smooth.